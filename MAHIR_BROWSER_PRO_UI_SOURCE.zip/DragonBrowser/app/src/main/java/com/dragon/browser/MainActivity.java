package com.dragon.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.util.TypedValue;
import android.view.Gravity;\nimport android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    static final String HOME = "https://www.google.com";
    static final String EXT_HOST = "dm.ext";
    private static final int REQ_FILE = 11;
    private static final int REQ_ZIP = 12;
    private static final int REQ_PERM = 13;

    // ------------------------------------------------------------------ state
    Ext ext;
    volatile int curId;
    volatile String curUrl = "";
    volatile String curTitle = "";

    private SharedPreferences prefs;
    private boolean desktop;
    private boolean docStart;
    private String mobileUA;
    private String desktopUA;

    private FrameLayout rootFrame;
    private FrameLayout content;
    private EditText urlBar;
    private ProgressBar progress;
    private TextView tabCount;

    private final ArrayList<Tab> tabs = new ArrayList<>();
    private Tab cur;
    private int tabSeq = 0;

    private final Map<WebView, ScriptHandler> handles = new HashMap<>();
    private final Map<String, BgPage> bgs = new HashMap<>();
    private final ArrayList<WebView> popupViews = new ArrayList<>();
    private final Map<Integer, Pending> pending = new HashMap<>();
    private int respSeq = 0;

    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;
    private PermissionRequest pendingPerm;

    static final class Tab {
        int id;
        WebView wv;
        String title = "";
        String url = "";
    }

    static final class BgPage {
        String extId;
        WebView wv;
        boolean loaded;
        final ArrayList<Runnable> queue = new ArrayList<>();

        void post(Runnable r) {
            if (loaded) r.run();
            else queue.add(r);
        }
    }

    static final class Pending {
        final WeakReference<WebView> wv;
        final int cb;

        Pending(WebView w, int cb) {
            this.wv = new WeakReference<>(w);
            this.cb = cb;
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("browser", MODE_PRIVATE);
        desktop = prefs.getBoolean("desktop", false);
        ext = new Ext(this);

        String def = WebSettings.getDefaultUserAgent(this);
        mobileUA = def.replace("; wv", "").replace("Version/4.0 ", "");
        Matcher m = Pattern.compile("Chrome/([\\d.]+)").matcher(def);
        String ver = m.find() ? m.group(1) : "120.0.0.0";
        desktopUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + ver + " Safari/537.36";

        boolean ds = false;
        try {
            ds = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        } catch (Throwable ignored) {
        }
        docStart = ds;

        buildUi();
        refreshExtensions();

        Uri data = getIntent() == null ? null : getIntent().getData();
        createTab(data != null ? data.toString() : HOME, null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Uri data = intent == null ? null : intent.getData();
        if (data != null) createTab(data.toString(), null);
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) {
            try {
                t.wv.destroy();
            } catch (Exception ignored) {
            }
        }
        for (BgPage bg : bgs.values()) {
            try {
                bg.wv.destroy();
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
            return;
        }
        if (cur != null && cur.wv.canGoBack()) {
            cur.wv.goBack();
            return;
        }
        if (tabs.size() > 1) {
            closeTab(cur);
            return;
        }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------ UI

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView barButton(String text, int sp, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(0xFFF5F5F5);
        GradientDrawable buttonBg = new GradientDrawable();
        buttonBg.setColor(0xFF1B1B1B);
        buttonBg.setCornerRadius(dp(13));
        buttonBg.setStroke(dp(1), 0xFF383838);
        t.setBackground(buttonBg);
        t.setPadding(dp(4), dp(3), dp(4), dp(3));
        t.setOnClickListener(l);
        return t;
    }

    private void buildUi() {
        getWindow().setStatusBarColor(0xFF080808);
        getWindow().getDecorView().setSystemUiVisibility(0);

        rootFrame = new FrameLayout(this);
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setBackgroundColor(0xFF080808);

        // top bar
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(0xFF101010);
        top.setPadding(dp(8), dp(6), dp(8), dp(6));

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        urlBar.setHint("Search or enter website");\n        urlBar.setHintTextColor(0xFF9A9A9A);\n        urlBar.setTextColor(0xFFFFFFFF);
        urlBar.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setPadding(dp(14), 0, dp(14), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF202020);\n        bg.setStroke(dp(1), 0xFF8E1717);
        bg.setCornerRadius(dp(20));
        urlBar.setBackground(bg);
        urlBar.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                loadInput(urlBar.getText().toString());
                urlBar.clearFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
                return true;
            }
            return false;
        });
        urlBar.setOnFocusChangeListener((v, has) -> {
            if (has) {
                if (cur != null && cur.url != null) urlBar.setText(cur.url);
                urlBar.selectAll();
            } else {
                refreshBar();
            }
        });
        top.addView(urlBar, new LinearLayout.LayoutParams(0, dp(40), 1f));
        TextView messengerQuick = barButton("MESS", 10, v -> openMessenger());
        messengerQuick.setTextColor(0xFFFFFFFF);
        GradientDrawable messengerBg = new GradientDrawable();
        messengerBg.setColor(0xFFB5121B);\n        messengerBg.setStroke(dp(1), 0xFFFF4545);
        messengerBg.setCornerRadius(dp(14));
        messengerQuick.setBackground(messengerBg);
        LinearLayout.LayoutParams messengerLp = new LinearLayout.LayoutParams(dp(40), dp(40));
        messengerLp.leftMargin = dp(7);
        top.addView(messengerQuick, messengerLp);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);

        content = new FrameLayout(this);

        // bottom bar
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setBackgroundColor(0xFF101010);
        LinearLayout.LayoutParams cell = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);

        bottom.addView(barButton("‹", 27, v -> {
            if (cur != null && cur.wv.canGoBack()) cur.wv.goBack();
        }), cell);
        bottom.addView(barButton("›", 27, v -> {
            if (cur != null && cur.wv.canGoForward()) cur.wv.goForward();
        }), new LinearLayout.LayoutParams(cell));
        bottom.addView(barButton("⋮", 24, v -> showMenu()), new LinearLayout.LayoutParams(cell));

        LinearLayout tabCell = new LinearLayout(this);
        tabCell.setGravity(Gravity.CENTER);
        tabCell.setOnClickListener(v -> showTabs());
        tabCount = new TextView(this);
        tabCount.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tabCount.setTextColor(0xFFFFFFFF);
        tabCount.setGravity(Gravity.CENTER);
        GradientDrawable box = new GradientDrawable();
        box.setStroke(dp(1), 0xFFE53935);\n        box.setColor(0xFF202020);
        box.setCornerRadius(dp(5));
        tabCount.setBackground(box);
        tabCell.addView(tabCount, new LinearLayout.LayoutParams(dp(26), dp(26)));
        bottom.addView(tabCell, new LinearLayout.LayoutParams(cell));

        bottom.addView(barButton("⌂", 23, v -> {
            if (cur != null) cur.wv.loadUrl(HOME);
        }), new LinearLayout.LayoutParams(cell));

        main.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        main.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));
        main.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        main.addView(bottom, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        rootFrame.addView(main, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rootFrame);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static String displayUrl(String u) {
        if (u == null) return "";
        String s = u;
        if (s.startsWith("https://")) s = s.substring(8);
        else if (s.startsWith("http://")) s = s.substring(7);
        if (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    private void refreshBar() {
        if (urlBar != null && !urlBar.hasFocus()) {
            urlBar.setText(cur == null ? "" : displayUrl(cur.url));
        }
        tabCount.setText(String.valueOf(tabs.size()));
    }

    private void syncCur() {
        if (cur != null) {
            curId = cur.id;
            curUrl = cur.url == null ? "" : cur.url;
            curTitle = cur.title == null ? "" : cur.title;
        }
    }

    private void loadInput(String in) {
        String s = in == null ? "" : in.trim();
        if (s.length() == 0 || cur == null) return;
        String u;
        if (s.toLowerCase().startsWith("javascript:")) return;
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
            u = s;
        } else if (s.startsWith("localhost") || s.matches("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")) {
            u = "http://" + s;
        } else if (!s.contains(" ") && s.contains(".") && !s.endsWith(".")) {
            u = "https://" + s;
        } else {
            u = "https://www.google.com/search?q=" + Uri.encode(s);
        }
        cur.wv.loadUrl(u);
    }

    // ------------------------------------------------------------------ tabs

    Tab tabById(int id) {
        for (Tab t : tabs) if (t.id == id) return t;
        return null;
    }

    void openUrlInNewTab(final String url) {
        runOnUiThread(() -> {
            if (url != null && url.length() > 0) createTab(url, null);
        });
    }

    private Tab createTab(String url, WebView existing) {
        Tab t = new Tab();
        t.id = ++tabSeq;
        t.wv = existing != null ? existing : new WebView(this);
        setupWebView(t);
        tabs.add(t);
        selectTab(t);
        if (existing == null && url != null) t.wv.loadUrl(url);
        return t;
    }

    private void selectTab(Tab t) {
        cur = t;
        content.removeAllViews();
        if (t.wv.getParent() instanceof ViewGroup) ((ViewGroup) t.wv.getParent()).removeView(t.wv);
        content.addView(t.wv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        progress.setVisibility(View.GONE);
        syncCur();
        if (urlBar != null && urlBar.hasFocus()) urlBar.clearFocus();
        refreshBar();
        t.wv.requestFocus();
    }

    private void closeTab(Tab t) {
        if (t == null) return;
        if (tabs.size() <= 1) {
            t.wv.loadUrl(HOME);
            return;
        }
        int i = tabs.indexOf(t);
        tabs.remove(t);
        content.removeView(t.wv);
        dropHandle(t.wv);
        try {
            t.wv.destroy();
        } catch (Exception ignored) {
        }
        if (cur == t) selectTab(tabs.get(Math.max(0, Math.min(i, tabs.size() - 1))));
        else refreshBar();
    }

    private void showTabs() {
        final ArrayList<Tab> list = new ArrayList<>(tabs);
        String[] items = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            Tab t = list.get(i);
            String title = (t.title != null && t.title.length() > 0) ? t.title : displayUrl(t.url);
            if (title.length() == 0) title = "নতুন ট্যাব";
            items[i] = (t == cur ? "● " : "○ ") + title;
        }
        new AlertDialog.Builder(new ContextThemeWrapper(this, android.R.style.Theme_Material_Dialog_Alert))
                .setTitle("ট্যাব (" + list.size() + ")")
                .setItems(items, (d, which) -> selectTab(list.get(which)))
                .setPositiveButton("নতুন ট্যাব", (d, w) -> createTab(HOME, null))
                .setNeutralButton("এই ট্যাব বন্ধ", (d, w) -> closeTab(cur))
                .setNegativeButton("বন্ধ", null)
                .show();
    }

    // ------------------------------------------------------------------ WebView setup

    private void applyUA(WebSettings s) {
        s.setUserAgentString(desktop ? desktopUA : mobileUA);
    }

    private void setupWebView(final Tab t) {
        final WebView w = t.wv;
        w.setBackgroundColor(Color.WHITE);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setAllowFileAccess(false);
        applyUA(s);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);

        Bridge br = new Bridge(this, "tab", t.id);
        br.attach(w);
        w.addJavascriptInterface(br, "__DM");
        installBootstrap(w, ext.tabBootstrap());

        w.setWebViewClient(new TabClient(t));
        w.setWebChromeClient(new TabChrome(t));
        w.setDownloadListener((url, ua, cd, mime, len) -> startDownload(url, ua, cd, mime));
    }

    private void startDownload(String url, String ua, String cd, String mime) {
        try {
            String fn = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null) r.setMimeType(mime);
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            String ck = CookieManager.getInstance().getCookie(url);
            if (ck != null) r.addRequestHeader("Cookie", ck);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            toast("ডাউনলোড শুরু: " + fn);
        } catch (Exception e) {
            toast("ডাউনলোড করা গেল না");
        }
    }

    private void dropHandle(WebView w) {
        ScriptHandler h = handles.remove(w);
        if (h != null) {
            try {
                h.remove();
            } catch (Throwable ignored) {
            }
        }
    }

    private void installBootstrap(WebView w, String js) {
        dropHandle(w);
        if (!docStart) return;
        try {
            ScriptHandler h = WebViewCompat.addDocumentStartJavaScript(w, js, Collections.singleton("*"));
            handles.put(w, h);
        } catch (Throwable ignored) {
        }
    }

    private boolean handleExternal(String u) {
        if (u == null) return false;
        if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:")
                || u.startsWith("data:") || u.startsWith("blob:") || u.startsWith("javascript:")
                || u.startsWith("file:")) {
            return false;
        }
        try {
            Intent i;
            if (u.startsWith("intent:")) {
                i = Intent.parseUri(u, Intent.URI_INTENT_SCHEME);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setComponent(null);
                i.setSelector(null);
            } else {
                i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            }
            startActivity(i);
        } catch (Exception e) {
            toast("এই লিংক খোলা গেল না");
        }
        return true;
    }

    private final class TabClient extends WebViewClient {
        private final Tab t;

        TabClient(Tab t) {
            this.t = t;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            WebResourceResponse x = ext.serveIfExt(r.getUrl());
            return x != null ? x : super.shouldInterceptRequest(v, r);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return handleExternal(r.getUrl().toString());
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap favicon) {
            t.url = url;
            if (!handles.containsKey(v)) v.evaluateJavascript(ext.tabBootstrap(), null);
            if (t == cur) {
                syncCur();
                refreshBar();
            }
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            t.url = url;
            if (t == cur) {
                syncCur();
                refreshBar();
            }
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (r.isForMainFrame()) {
                String page = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                        + "<body style='font-family:sans-serif;text-align:center;padding:40px 16px;color:#444'>"
                        + "<h2>পেজ লোড হয়নি</h2><p>ইন্টারনেট বা ঠিকানা চেক করে আবার চেষ্টা করুন।</p>"
                        + "<p style='color:#999;font-size:13px'>" + e.getDescription() + "</p></body></html>";
                String u = r.getUrl().toString();
                v.loadDataWithBaseURL(u, page, "text/html", "utf-8", u);
            }
        }
    }

    private final class TabChrome extends WebChromeClient {
        private final Tab t;

        TabChrome(Tab t) {
            this.t = t;
        }

        @Override
        public void onProgressChanged(WebView v, int p) {
            if (t != cur) return;
            progress.setProgress(p);
            progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
        }

        @Override
        public void onReceivedTitle(WebView v, String title) {
            t.title = title == null ? "" : title;
            if (t == cur) syncCur();
        }

        @Override
        public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            WebView nw = new WebView(MainActivity.this);
            createTab(null, nw);
            WebView.WebViewTransport tr = (WebView.WebViewTransport) resultMsg.obj;
            tr.setWebView(nw);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onCloseWindow(WebView window) {
            for (Tab x : new ArrayList<>(tabs)) {
                if (x.wv == window) {
                    closeTab(x);
                    return;
                }
            }
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(p.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        @Override
        public void onPermissionRequest(final PermissionRequest req) {
            runOnUiThread(() -> handlePermission(req));
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCb = cb;
            view.setBackgroundColor(Color.BLACK);
            rootFrame.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }

        @Override
        public void onHideCustomView() {
            hideCustom();
        }
    }

    private void hideCustom() {
        if (customView == null) return;
        rootFrame.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    // ------------------------------------------------------------------ camera / mic permission

    private void handlePermission(PermissionRequest req) {
        ArrayList<String> need = new ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.RECORD_AUDIO);
            }
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.CAMERA);
            }
        }
        if (need.isEmpty()) {
            req.grant(req.getResources());
            return;
        }
        if (pendingPerm != null) pendingPerm.deny();
        pendingPerm = req;
        requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_PERM || pendingPerm == null) return;
        PermissionRequest req = pendingPerm;
        pendingPerm = null;
        ArrayList<String> ok = new ArrayList<>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)
                    && checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                ok.add(r);
            }
        }
        if (ok.isEmpty()) req.deny();
        else req.grant(ok.toArray(new String[0]));
    }

    // ------------------------------------------------------------------ menu

    private void showMenu() {
        final String[] items = {
                "নতুন ট্যাব",
                "Messenger খুলুন",
                "ডেস্কটপ মোড:  " + (desktop ? "চালু ✔" : "বন্ধ"),
                "এক্সটেনশন (জিপ ফাইল)",
                "রিফ্রেশ",
                "লিংক কপি",
                "শেয়ার",
                "ক্যাশ ও কুকি মুছুন"
        };
        new AlertDialog.Builder(new ContextThemeWrapper(this, android.R.style.Theme_Material_Dialog_Alert)).setItems(items, (d, which) -> {
            switch (which) {
                case 0:
                    createTab(HOME, null);
                    break;
                case 1:
                    openMessenger();
                    break;
                case 2:
                    toggleDesktop();
                    break;
                case 3:
                    showExtensions();
                    break;
                case 4:
                    if (cur != null) cur.wv.reload();
                    break;
                case 5:
                    if (cur != null && cur.url != null) {
                        ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cb != null) cb.setPrimaryClip(ClipData.newPlainText("url", cur.url));
                        toast("লিংক কপি হয়েছে");
                    }
                    break;
                case 6:
                    if (cur != null && cur.url != null) {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, cur.url);
                        startActivity(Intent.createChooser(i, "শেয়ার"));
                    }
                    break;
                case 7:
                    confirmClear();
                    break;
                default:
                    break;
            }
        }).show();
    }

    private void openMessenger() {
        try {
            Intent app = getPackageManager().getLaunchIntentForPackage("com.facebook.orca");
            if (app != null) {
                startActivity(app);
            } else {
                createTab("https://www.messenger.com", null);
            }
        } catch (Exception e) {
            createTab("https://www.messenger.com", null);
        }
    }

    private void toggleDesktop() {
        desktop = !desktop;
        prefs.edit().putBoolean("desktop", desktop).apply();
        for (Tab t : tabs) applyUA(t.wv.getSettings());
        if (cur != null) cur.wv.reload();
        toast(desktop ? "ডেস্কটপ মোড চালু" : "ডেস্কটপ মোড বন্ধ");
    }

    private void confirmClear() {
        new AlertDialog.Builder(new ContextThemeWrapper(this, android.R.style.Theme_Material_Dialog_Alert))
                .setMessage("সব ক্যাশ, কুকি আর লগইন মুছে যাবে। ঠিক আছে?")
                .setPositiveButton("মুছুন", (d, w) -> {
                    CookieManager.getInstance().removeAllCookies(null);
                    WebStorage.getInstance().deleteAllData();
                    for (Tab t : tabs) t.wv.clearCache(true);
                    toast("মুছে ফেলা হয়েছে");
                })
                .setNegativeButton("না", null)
                .show();
    }

    // ------------------------------------------------------------------ extensions UI

    private void showExtensions() {
        final List<Ext.Info> list = ext.list();
        String[] items = new String[list.size() + 1];
        items[0] = "＋ জিপ ফাইল যোগ করুন";
        for (int i = 0; i < list.size(); i++) {
            Ext.Info e = list.get(i);
            items[i + 1] = (e.enabled ? "✔ " : "✖ ") + e.name + (e.version.length() > 0 ? "  v" + e.version : "");
        }
        new AlertDialog.Builder(new ContextThemeWrapper(this, android.R.style.Theme_Material_Dialog_Alert))
                .setTitle("এক্সটেনশন")
                .setItems(items, (d, which) -> {
                    if (which == 0) pickZip();
                    else showExtActions(list.get(which - 1));
                })
                .setNegativeButton("বন্ধ", null)
                .show();
    }

    private void showExtActions(final Ext.Info e) {
        final ArrayList<String> items = new ArrayList<>();
        final boolean hasPopup = e.popupPath() != null;
        if (hasPopup) items.add("পপআপ / প্যানেল খুলুন");
        items.add(e.enabled ? "বন্ধ করুন" : "চালু করুন");
        items.add("মুছে ফেলুন");
        new AlertDialog.Builder(new ContextThemeWrapper(this, android.R.style.Theme_Material_Dialog_Alert))
                .setTitle(e.name)
                .setItems(items.toArray(new String[0]), (d, which) -> {
                    int idx = which - (hasPopup ? 1 : 0);
                    if (hasPopup && which == 0) {
                        openPopup(e);
                    } else if (idx == 0) {
                        ext.setEnabled(e.id, !e.enabled);
                        onExtensionsChanged();
                    } else {
                        ext.delete(e.id);
                        onExtensionsChanged();
                        toast("মুছে ফেলা হয়েছে");
                    }
                })
                .setNegativeButton("বন্ধ", null)
                .show();
    }

    private void pickZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/zip", "application/x-zip-compressed", "application/x-zip", "application/octet-stream"});
        try {
            startActivityForResult(i, REQ_ZIP);
        } catch (Exception e) {
            toast("ফাইল পিকার খোলা গেল না");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (fileCb != null) {
                Uri[] r = WebChromeClient.FileChooserParams.parseResult(res, data);
                fileCb.onReceiveValue(r);
                fileCb = null;
            }
        } else if (req == REQ_ZIP) {
            if (res == RESULT_OK && data != null && data.getData() != null) installZip(data.getData());
        }
    }

    private void installZip(final Uri uri) {
        toast("এক্সটেনশন যোগ হচ্ছে...");
        new Thread(() -> {
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) throw new Exception("ফাইল পড়া যায়নি");
                final Ext.Info info;
                try {
                    info = ext.install(in);
                } finally {
                    in.close();
                }
                runOnUiThread(() -> {
                    toast("যোগ হয়েছে: " + (info == null ? "" : info.name));
                    onExtensionsChanged();
                    if (cur != null) cur.wv.reload();
                });
            } catch (final Exception e) {
                runOnUiThread(() -> toast("জিপ কাজ করেনি: " + e.getMessage()));
            }
        }).start();
    }

    private void onExtensionsChanged() {
        refreshExtensions();
    }

    /** Rebuilds background pages and re-registers the content-script bootstrap in every tab. */
    private void refreshExtensions() {
        for (BgPage b : bgs.values()) {
            rootFrame.removeView(b.wv);
            dropHandle(b.wv);
            try {
                b.wv.destroy();
            } catch (Exception ignored) {
            }
        }
        bgs.clear();
        for (Ext.Info i : ext.list()) {
            if (i.enabled && i.hasBackground()) createBg(i);
        }
        String js = ext.tabBootstrap();
        for (Tab t : tabs) installBootstrap(t.wv, js);
    }

    // ------------------------------------------------------------------ extension pages (background / popup)

    private void configureExtWebView(WebView w, String kind, String extId) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        Bridge br = new Bridge(this, kind, 0);
        br.attach(w);
        w.addJavascriptInterface(br, "__DM");
        installBootstrap(w, ext.pageBootstrap(extId));
    }

    private final class ExtPageClient extends WebViewClient {
        private final String extId;
        private final Runnable onFinish;

        ExtPageClient(String extId, Runnable onFinish) {
            this.extId = extId;
            this.onFinish = onFinish;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            WebResourceResponse x = ext.serveIfExt(r.getUrl());
            return x != null ? x : super.shouldInterceptRequest(v, r);
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap f) {
            if (!handles.containsKey(v)) v.evaluateJavascript(ext.pageBootstrap(extId), null);
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            if (onFinish != null) onFinish.run();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            if (EXT_HOST.equals(r.getUrl().getHost())) return false;
            openUrlInNewTab(r.getUrl().toString());
            return true;
        }
    }

    private void createBg(Ext.Info i) {
        final BgPage b = new BgPage();
        b.extId = i.id;
        b.wv = new WebView(this);
        configureExtWebView(b.wv, "bg", i.id);
        b.wv.setWebViewClient(new ExtPageClient(i.id, () -> {
            if (!b.loaded) {
                b.loaded = true;
                ArrayList<Runnable> q = new ArrayList<>(b.queue);
                b.queue.clear();
                for (Runnable r : q) r.run();
            }
        }));
        b.wv.setAlpha(0f);
        rootFrame.addView(b.wv, new FrameLayout.LayoutParams(1, 1));
        bgs.put(i.id, b);
        b.wv.loadUrl("https://" + EXT_HOST + Ext.PREFIX + i.id + "/_bg.html");
    }

    private void openPopup(Ext.Info e) {
        String p = e.popupPath();
        if (p == null) {
            toast("এই এক্সটেনশনে পপআপ নেই");
            return;
        }
        final Dialog d = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("✕   " + e.name);
        title.setTextColor(0xFFFFD27A);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(14), 0, dp(14), 0);
        title.setBackgroundColor(0xFF111111);
        title.setOnClickListener(v -> d.dismiss());

        final WebView w = new WebView(this);
        w.setBackgroundColor(Color.BLACK);
        configureExtWebView(w, "popup", e.id);
        w.setWebViewClient(new ExtPageClient(e.id, null));
        popupViews.add(w);

        box.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        box.addView(w, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        d.setContentView(box);
        d.setOnDismissListener(x -> {
            popupViews.remove(w);
            dropHandle(w);
            try {
                w.destroy();
            } catch (Exception ignored) {
            }
        });
        d.show();
        if (d.getWindow() != null) {
            d.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
        w.loadUrl("https://" + EXT_HOST + Ext.PREFIX + e.id + "/" + p);
    }

    // ------------------------------------------------------------------ message routing (called by Bridge)

    private String senderJson(Bridge from, String extId) {
        JSONObject s = new JSONObject();
        try {
            s.put("id", extId);
            if ("tab".equals(from.kindName())) {
                Tab t = tabById(from.tabIdValue());
                JSONObject tb = new JSONObject();
                tb.put("id", from.tabIdValue());
                tb.put("url", t == null || t.url == null ? "" : t.url);
                tb.put("title", t == null || t.title == null ? "" : t.title);
                s.put("tab", tb);
                s.put("frameId", 0);
                s.put("url", t == null || t.url == null ? "" : t.url);
            }
        } catch (JSONException ignored) {
        }
        return s.toString();
    }

    void route(final Bridge from, final String extId, final String target, final int destTab,
               final String msg, final int cbId) {
        runOnUiThread(() -> {
            final int rid = ++respSeq;
            pending.put(rid, new Pending(from.webView(), cbId));
            final String sender = senderJson(from, extId);
            if ("bg".equals(target)) {
                final BgPage b = bgs.get(extId);
                if (b == null) {
                    respond(rid, "null");
                    return;
                }
                b.post(() -> deliver(b.wv, extId, msg, sender, rid));
            } else {
                Tab t = tabById(destTab);
                if (t == null) {
                    respond(rid, "null");
                    return;
                }
                deliver(t.wv, extId, msg, sender, rid);
            }
        });
    }

    private void deliver(WebView dest, String extId, String msg, String sender, final int rid) {
        String js = "(window.__dmDeliver?(window.__dmDeliver(" + JSONObject.quote(extId) + ","
                + JSONObject.quote(msg == null ? "null" : msg) + "," + JSONObject.quote(sender) + "," + rid + "),1):0)";
        dest.evaluateJavascript(js, value -> {
            if (!"1".equals(value)) respond(rid, "null");
        });
    }

    void respond(final int rid, final String json) {
        runOnUiThread(() -> {
            Pending p = pending.remove(rid);
            if (p == null) return;
            WebView w = p.wv.get();
            if (w != null) {
                w.evaluateJavascript("window.__dmCb&&window.__dmCb(" + p.cb + ","
                        + JSONObject.quote(json == null ? "null" : json) + ")", null);
            }
        });
    }

    void broadcastChanges(final String extId, final String changesJson) {
        runOnUiThread(() -> {
            final String js = "window.__dmChanged&&window.__dmChanged(" + JSONObject.quote(extId) + ","
                    + JSONObject.quote(changesJson) + ",'local')";
            for (Tab t : tabs) t.wv.evaluateJavascript(js, null);
            for (final BgPage b : bgs.values()) b.post(() -> b.wv.evaluateJavascript(js, null));
            for (WebView w : new ArrayList<>(popupViews)) w.evaluateJavascript(js, null);
        });
    }
}
